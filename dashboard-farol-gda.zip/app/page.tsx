export default function Page() {
  return (
    <iframe
      src="/index.html"
      title="Dashboard Farol - GDA"
      style={{
        position: 'fixed',
        inset: 0,
        width: '100%',
        height: '100%',
        border: 'none',
      }}
    />
  )
}
